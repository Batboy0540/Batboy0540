<?php

$name = $_POST['name']
$email = $_POST['email']
$subject = $_POST['subject']

$mailheader = "From:".$name."<".$email.">\r\n":

$recipient = "Parzivall8@duck.com";

mail($recipient, $subject, $message, $mailheader);
or die("Error!");

echo"message send";

?>